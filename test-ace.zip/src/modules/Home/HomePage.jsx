import Hero from "./Hero/Hero";

const Home = () => {
  return (
    <div className="bg-[#EDF9FF] lg:h-[1024px] md:h-[813px] h-[1320px]">
      <Hero />
    </div>
  );
};

export default Home;
